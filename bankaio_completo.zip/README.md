# @firebase/component

_NOTE: This is specifically tailored for Firebase JS SDK usage, if you are not a
member of the Firebase team, please avoid using this package_

## Usage

**ES Modules**

```javascript
import { Component } from '@firebase/component';
```
