import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:bankaio/main_emuladores.dart' as app;
import 'package:flutter/material.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  /// Helper para reiniciar la app entre tests
  Future<void> restartApp(WidgetTester tester) async {
    debugPrint('🔄 Reiniciando app para estado limpio...');
    try {
      // Intentar usar reassembleApplication para un reinicio más robusto
      await tester.binding.reassembleApplication();
      await tester.pumpAndSettle(const Duration(seconds: 3));
      debugPrint('✅ App reiniciada con reassembleApplication');
    } catch (e) {
      debugPrint('⚠️ Fallback a main(): $e');
      await app.main();
      await tester.pumpAndSettle(const Duration(seconds: 5));
      debugPrint('✅ App reiniciada con main()');
    }
  }

  testWidgets('Carga de pantalla de login', (WidgetTester tester) async {
    await restartApp(tester); // Usar helper en lugar de app.main() directamente

    // Validaciones básicas
    expect(find.text('Usuario'), findsOneWidget);
    expect(find.text('Contraseña'), findsOneWidget);
    expect(find.text('Ingresar'), findsOneWidget);
  });
}

/*
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:bankaio/main_emuladores.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('Carga de pantalla de login', (WidgetTester tester) async {
    await app.main(); // Ejecuta tu app desde main_emuladores.dart
    await tester.pumpAndSettle(); // Espera a que todo esté renderizado

    // Validaciones básicas
    expect(find.text('Usuario'), findsOneWidget);
    expect(find.text('Contraseña'), findsOneWidget);
    expect(find.text('Ingresar'), findsOneWidget);
  });
}
*/